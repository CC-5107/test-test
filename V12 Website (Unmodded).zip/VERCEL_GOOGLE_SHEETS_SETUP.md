# Vercel + Direct Google Sheets Setup

This version no longer uses `connector-gateway.lovable.dev`, `LOVABLE_API_KEY`, or `GOOGLE_SHEETS_API_KEY` for project-sheet access.

## 1. Google Cloud

1. Open Google Cloud Console and select/create a project.
2. Enable **Google Sheets API**.
3. Go to **IAM & Admin → Service Accounts** and create a service account.
4. Open the service account → **Keys → Add key → Create new key → JSON**.
5. Keep the downloaded JSON private. Do not upload it to GitHub.

From the JSON you need:

- `client_email`
- `private_key`

## 2. Share the spreadsheet

Open the live project spreadsheet and share it with the service account `client_email` as **Editor**:

`17Y47rJ8alS9tiAUvKYR5ADlhWoGZrHo_2FFJdvTLnYs`

The website can only write to sheets that have been explicitly shared with the service account.

## 3. Vercel environment variables

In **Vercel → Project → Settings → Environment Variables**, add:

### GOOGLE_SERVICE_ACCOUNT_EMAIL
Paste the JSON `client_email` value.

### GOOGLE_PRIVATE_KEY
Paste the full JSON `private_key` value, including:

`-----BEGIN PRIVATE KEY-----`

and

`-----END PRIVATE KEY-----`

The code accepts either real line breaks or literal `\n` sequences.

### GOOGLE_SPREADSHEET_ID
Set to:

`17Y47rJ8alS9tiAUvKYR5ADlhWoGZrHo_2FFJdvTLnYs`

This variable is optional because the same ID is also retained as a fallback in the code, but setting it in Vercel is recommended.

Apply the variables to **Production**, and Preview too if you want preview deployments to access the sheet.

## 4. Redeploy

After adding/changing environment variables, redeploy the Vercel project. Environment-variable changes do not affect an already-built deployment.

## 5. Optional legacy activity spreadsheet

The app still contains the older background `Active`-sheet logger. If you want it to keep working too, set:

`CRM_SPREADSHEET_ID=1lwLc4FepNQDAyRCWEbq5EDZYLjyE7SAGdzYO99YJHy8`

and share that spreadsheet with the same service-account email as Editor.

Failure of this optional activity log does not prevent the main Firebase/project-sheet save path.

## Security

- Never put the service-account private key in `src/`, Firebase client config, or any `VITE_*` variable.
- Never commit the downloaded service-account JSON file to GitHub.
- The private key is only read by server-side `.server.ts` code.
