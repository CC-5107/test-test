# Firebase app-data setup

The app now uses the existing Firebase project in `src/firebase.js`.

## Firestore location

Collection: `appData`

Document: `main`

It stores the shared dashboard state:

- `projects`
- `companies`
- `contacts`
- `updatedAt`
- `updatedBy`
- `schemaVersion`

The collection/document is created automatically on the first successful save.

## Firestore rules

The included `firestore.rules` permits authenticated users to read/write
`appData/main` while preserving the current username login lookup.

If your Firebase console currently has different rules, merge/deploy the
`appData` rule before testing persistence.
